﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasoPractico1_JoseDavidVargas.LogicaDeNegocios
{
    public class Class1
    {
    }
}
